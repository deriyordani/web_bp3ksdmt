
<div id="kurs_all" class="content">

	<table border="1">
		<thead>
			<tr>
				<td></td>
				<td><?php echo $text_simbol; ?></td>
				<td><?php echo $text_beli; ?></td>
				<td><?php echo $text_jual; ?></td>
			</tr>
		</thead>
		<tbody>
			<?php
			echo "<tr>";

			echo $kurs;

			?>
		</tbody>
	</table>

</div>