<div id="peta_atm" class="content">

	<div id="jendelainfo">
        <div class="dialog-content">
            <div id="dialog-message">
            	<p align="center">
            		<span id="teksjenis"></span><br><br>
            	</p>
            	<span><?php echo $text_lokasi ?> : </span><span id="teksjudul"></span><br>
            	<span><?php echo $text_alamat ?> : </span><span id="tekslokasi"></span><br>
            	<span><?php echo $text_keterangan ?> : </span><span id="teksdes"></span><br>
            </div>
            <a style="cursor:pointer" id="tutup" onClick="close_deskripsi()" class="button">Close</a>
        </div>
    </div>


	<div id="wp_petaku"><div id="petaku" style="height:500px"></div></div><br><br>
	<?php echo $text_keterangan ?> : ATM = Anjungan Tunai Mandiri; ANT = ATM Non Tunai; AST = ATM Setoran Tunai
</div>