<div class="box_style_1">
	<?php echo "$notif"; ?>
</div>