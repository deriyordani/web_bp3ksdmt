<!-- Contact -->
<div class="box_style_1">
    <h4>BP3K SDMT</h4>
                        <?php
                        foreach ($home_sets as $key => $home_set) {
                            if($home_set->key == 'contact'){
                                echo $home_set->content_setting_website;
                            }
                        }
                        ?>

    <br><br><br>

                            <div class="indent_title_in">
                                <i class="pe-7s-mail-open-file"></i>
                                <h3><?php echo $text_form; ?></h3>
                            </div>
                            <div class="wrapper_indent">
                                <div id="message-contact"></div>
                                <form method="post">
                                    <?php echo $benar; ?>
                                    <div class="row">
                                        <div class="col-md-12 col-sm-12">
                                            <div class="form-group">
                                                <label><?php echo $text_name; ?></label>
                                                <input type="text" class="form-control styled" name="name" placeholder="<?php echo $text_name; ?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6 col-sm-6">
                                            <div class="form-group">
                                                <label><?php echo $text_email; ?></label>
                                                <input type="email" class="form-control styled" name="email" placeholder="<?php echo $text_email; ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-sm-6">
                                            <div class="form-group">
                                                <label><?php echo $text_phone; ?></label>
                                                <input type="text" class="form-control styled" name="phone" placeholder="<?php echo $text_phone; ?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo $text_message; ?></label>
                                                <textarea rows="5" name="message" class="form-control styled" style="height:100px;" placeholder="<?php echo $text_message; ?>"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Captcha</label>
                                                <?php echo $recaptcha_html; ?>
                                            </div>
                                            <input type="submit" value="<?php echo $text_send; ?>" class="button add_bottom_30" id="submit-contact"/>
                                        </div>
                                    </div>
                                </form>
                            </div><!-- End wrapper_indent -->      


<!-- Map 
<div class="map">
<iframe width="622" height="400" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.co.id/maps?ie=UTF8&amp;cid=3316231373823807116&amp;q=Bank+Maluku+Kantor+Pusat&amp;gl=ID&amp;hl=en&amp;t=m&amp;ll=-3.700022,128.098837&amp;spn=0.004283,0.006663&amp;z=17&amp;iwloc=A&amp;output=embed"></iframe><br /><small><a href="https://maps.google.co.id/maps?ie=UTF8&amp;cid=3316231373823807116&amp;q=Bank+Maluku+Kantor+Pusat&amp;gl=ID&amp;hl=en&amp;t=m&amp;ll=-3.700022,128.098837&amp;spn=0.004283,0.006663&amp;z=17&amp;iwloc=A&amp;source=embed" style="color:#0000FF;text-align:left">View Larger Map</a></small>
</div>
 [end] Map -->

</div>
<!-- [end] Contact -->