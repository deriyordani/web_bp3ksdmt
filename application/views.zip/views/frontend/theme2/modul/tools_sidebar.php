<!-- simulasi -->
<div class="simulation floated-left mr-20">
	<h2 class="head-title p20">Tools</h2>
	<div>
		<label>Simulasi Kredit</label>
		<div class="filter-simulasi">
			<span class="teks">Simulasi Kredit</span>
			<span class="icon-drop"></span>
			<ul class="filtering">
				<li><a href="#" id="kk">Simulasi Kredit</a></li>
			</ul>
		</div>
		<input type="button" class="btn" value="GO" onClick="window.location = '<?php echo base_url()?>modul/simulasi_produk'" />
	</div>
	<div>
		<label>Lokasi dan Jaringan</label>
		<div class="filter-simulasi">
			<span class="teks">ATM</span>
			<span class="icon-drop"></span>
			<ul class="filtering">
				<li><a href="#" id="kk">ATM</a></li>
			</ul>
		</div>
		<input type="submit" class="btn" value="GO" onClick="window.location = '<?php echo base_url()?>modul/peta_atm'" />
	</div>
</div>
<!-- [end] simulasi -->