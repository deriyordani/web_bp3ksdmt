
<label class="mws-form-label">Jenis Opsi</label>
<div class="mws-form-item">
	<?php echo form_dropdown('id_jenis', $list_jenis, '', 'class="small"'); ?><br />
</div>

