	<?php date_default_timezone_set('Asia/Jakarta'); ?>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<title>Bank Maluku - Mitra Usaha Anda</title>
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width">

	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->

	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
	<script>window.jQuery || document.write('<script src="<?php echo base_url()?>assets/theme3/js/jquery-1.9.0.min.js"><\/script>')</script>
	
	<link rel="stylesheet" href="<?php echo base_url()?>assets/theme3/css/reset.css">
    <link rel="stylesheet" href="<?php echo base_url()?>assets/theme3/css/main.css">

	<script src="<?php echo base_url()?>assets/theme3/js/modernizr-2.6.2.min.js"></script>
	
	<link href="<?php echo base_url()?>assets/theme3/images/icon.png" rel="icon">

	<!-- Add fancyBox main JS and CSS files -->
	<script type="text/javascript" src="<?php echo base_url()?>assets/source/jquery.fancybox.js?v=2.1.5"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/source/jquery.fancybox.css?v=2.1.5" media="screen" />

	<script type="text/javascript">
		$(document).ready(function() {
			/*
			 *  Simple image gallery. Uses default settings
			 */

			$('.fancybox').fancybox();

			});
	</script>