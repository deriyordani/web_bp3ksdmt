<div id="box-footer">
	<div class="box-main">
		<!-- link -->
		<p class="copyright">
			<span>(0911) 312013</span><br/>
			<?php echo date('Y'); ?> &copy; Bank Maluku. All Rights Reserved.
		</p>
		<ul class="link-partner">
			<li><a href="" class="p-1">pemprov</a></li>
			<li><a href="" class="p-2">pemkot</a></li>
			<li><a href="" class="p-3">3p</a></li>
			<li><a href="" class="p-4">asbanda</a></li>
			<li class="spc"><a href="" class="p-5">ayo</a></li>
			<li><a href="" class="p-6">sahabat</a></li>
			<li class="spc"><a href="" class="p-7">bi</a></li>
		</ul>
		<div class="klir"></div>
		<!-- [end] link -->
		<div class="bluefoot"></div>
	</div>
</div>