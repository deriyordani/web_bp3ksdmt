<?php

$lang['text_home'] = 'Beranda';
$lang['text_corporate'] = 'Info Perusahaan';
$lang['text_contact'] = 'Kontak Kami';
$lang['text_site'] = 'Peta Situs';