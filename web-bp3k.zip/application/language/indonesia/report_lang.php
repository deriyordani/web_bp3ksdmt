<?php

$lang['text_title'] = 'Laporan';
$lang['text_home'] = 'Beranda';
$lang['text_download'] = 'Unduh';