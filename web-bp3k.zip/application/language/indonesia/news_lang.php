<?php

$lang['text_title'] = 'Berita';
$lang['text_home'] = 'Beranda';
$lang['text_read'] = 'Selengkapnya';
$lang['text_name'] = 'Nama';
$lang['text_email'] = 'Email';
$lang['text_url'] = 'Url';
$lang['text_comment'] = 'Komentar';
$lang['text_send'] = 'Kirim Komentar';
$lang['text_form'] = 'Komentar Form';
$lang['text_failed'] = 'Captcha Salah!';
$lang['text_success'] = 'Komentar Berhasil di Kirim.';

/* End of file news_lang.php */
/* Location: ./application/language/indonesia/news_lang.php */