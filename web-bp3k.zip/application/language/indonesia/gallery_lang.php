<?php

$lang['text_title'] = 'Galeri';
$lang['text_home'] = 'Beranda';