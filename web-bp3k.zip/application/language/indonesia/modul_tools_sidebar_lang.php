<?php

$lang['text_title'] = 'Tools';