<?php

$lang['text_title'] = 'Peta Sebaran ATM';
$lang['text_home'] = 'Beranda';
$lang['text_lokasi'] = 'Lokasi';
$lang['text_alamat'] = 'Alamat';
$lang['text_keterangan'] = 'Keterangan';