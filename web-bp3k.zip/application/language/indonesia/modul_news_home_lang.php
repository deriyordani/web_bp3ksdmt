<?php

$lang['text_featured'] = 'Berita Utama';
$lang['text_news'] = 'Berita';
$lang['text_view_news'] = 'tampilkan semua berita';

/* End of file home_lang.php */
/* Location: ./application/language/indonesia/modul_news_home_lang.php */