<?php

$lang['text_title'] = 'Peta Situs';
$lang['text_home'] = 'Beranda';