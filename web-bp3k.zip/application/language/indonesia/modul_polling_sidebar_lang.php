<?php

$lang['text_title'] = 'Polling';