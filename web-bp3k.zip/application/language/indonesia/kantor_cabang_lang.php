<?php

$lang['text_title'] = 'Kantor Cabang';
$lang['text_title_helper'] = 'Kantor Cabang Pembantu';
$lang['text_home'] = 'Beranda';
$lang['text_desc'] = 'Daftar Alamat Kantor Cabang :';
$lang['text_desc_helper'] = 'Daftar Alamat Kantor Cabang Pembantu :';
