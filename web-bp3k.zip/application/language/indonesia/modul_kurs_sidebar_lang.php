<?php

$lang['text_title'] = 'Kurs';
$lang['text_home'] = 'Beranda';
$lang['text_simbol'] = 'Simbol';
$lang['text_beli'] = 'Beli';
$lang['text_jual'] = 'Jual';
$lang['text_tampil'] = 'tampilkan semua';