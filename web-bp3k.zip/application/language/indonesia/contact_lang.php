<?php

$lang['text_title'] = 'Kontak';
$lang['text_home'] = 'Beranda';
$lang['text_name'] = 'Nama';
$lang['text_email'] = 'Email';
$lang['text_phone'] = 'Telepon';
$lang['text_message'] = 'Pesan';
$lang['text_send'] = 'Kirim Pesan';
$lang['text_form'] = 'Kontak Form';
$lang['text_failed'] = 'Captcha Salah!';
$lang['text_success'] = 'Pesan Berhasil di Kirim';

/* End of file contact_lang.php */
/* Location: ./application/language/indonesia/contact_lang.php */