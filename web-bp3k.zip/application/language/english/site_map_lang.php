<?php

$lang['text_title'] = 'Site Map';
$lang['text_home'] = 'Home';