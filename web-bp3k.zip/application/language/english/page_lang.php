<?php

$lang['text_title'] = 'Page';
$lang['text_home'] = 'Home';