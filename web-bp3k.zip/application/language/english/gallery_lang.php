<?php

$lang['text_title'] = 'Gallery';
$lang['text_home'] = 'Home';