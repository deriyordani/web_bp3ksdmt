<?php

$lang['text_title'] = 'Kurs';
$lang['text_home'] = 'Home';
$lang['text_simbol'] = 'Symbol';
$lang['text_beli'] = 'Buy';
$lang['text_jual'] = 'Sell';
$lang['text_tampil'] = 'view all';