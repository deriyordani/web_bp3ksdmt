<?php

$lang['text_title'] = 'Branch Office';
$lang['text_title_helper'] = 'Branch Office Helper';
$lang['text_home'] = 'Home';
$lang['text_desc'] = 'List Branch Office Address :';
$lang['text_desc_helper'] = 'List Branch Office Helper Address :';
