<?php

$lang['text_home'] = 'Home';
$lang['text_corporate'] = 'Corporate Info';
$lang['text_contact'] = 'Contact Us';
$lang['text_site'] = 'Site Map';