<?php

$lang['text_title'] = 'Report';
$lang['text_home'] = 'Home';
$lang['text_download'] = 'Download';