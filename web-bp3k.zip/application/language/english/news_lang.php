<?php

$lang['text_title'] = 'News';
$lang['text_home'] = 'Home';
$lang['text_read'] = 'Read More';
$lang['text_name'] = 'Name';
$lang['text_email'] = 'Email';
$lang['text_url'] = 'Url';
$lang['text_comment'] = 'Comment';
$lang['text_send'] = 'Send Comment';
$lang['text_form'] = 'Comment Form';
$lang['text_failed'] = 'Wrong Captcha!';
$lang['text_success'] = 'Send Comment Success.';

/* End of file news_lang.php */
/* Location: ./application/language/english/news_lang.php */