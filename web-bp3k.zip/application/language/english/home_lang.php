<?php

$lang['text_featured'] = 'Featured News';
$lang['text_news'] = 'News';
$lang['text_view_news'] = 'view all news';

/* End of file home_lang.php */
/* Location: ./application/language/english/home_lang.php */