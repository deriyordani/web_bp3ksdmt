<?php

$lang['text_title'] = 'Contact';
$lang['text_home'] = 'Home';
$lang['text_name'] = 'Name';
$lang['text_email'] = 'Email';
$lang['text_phone'] = 'Phone';
$lang['text_message'] = 'Message';
$lang['text_send'] = 'Send Message';
$lang['text_form'] = 'Contact Form';
$lang['text_failed'] = 'Wrong Captcha!';
$lang['text_success'] = 'Send Message Success.';

/* End of file contact_lang.php */
/* Location: ./application/language/english/contact_lang.php */