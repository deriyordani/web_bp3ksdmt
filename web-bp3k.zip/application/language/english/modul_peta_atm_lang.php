<?php

$lang['text_title'] = 'Peta Sebaran ATM';
$lang['text_home'] = 'Home';
$lang['text_lokasi'] = 'Location';
$lang['text_alamat'] = 'Address';
$lang['text_keterangan'] = 'Information';